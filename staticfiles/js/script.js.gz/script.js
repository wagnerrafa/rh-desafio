function imagem(){
    document.getElementById("imagem").innerHTML="Imagem selecionada"
}
function formulario(){
    document.getElementById("formColaborador").style.display = 'block'
    
}