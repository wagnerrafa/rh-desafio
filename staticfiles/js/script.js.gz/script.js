function imagem(){
    document.getElementById("imagem").innerHTML="Imagem selecionada"
}
function formulario(){
    document.getElementById("formulario").style.display = 'flex'
    
}